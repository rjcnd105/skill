
var cc = require('..')

//should not throw
cc(__dirname, 'non_existing_file')
