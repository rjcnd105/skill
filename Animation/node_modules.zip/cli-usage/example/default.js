var usage = require('../');

usage();