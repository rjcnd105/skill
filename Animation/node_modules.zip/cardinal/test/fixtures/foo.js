function foo() { 
  var a = 3; return a > 2 ? true : false; 
}
